clc 
clear all;

filename='F:\Emotiv_offline\data\123-5555-19.02.16.19.51.19.edf';

[dat, marker, hdr]=Load_Emotiv(filename);



% hdr=Load_EM_hdr
% 
% dat=load_EM_data
% 
% marker-Load_EM_mrk