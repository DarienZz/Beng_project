clc
clear all;
close all;

Load_Emotiv_data(Emotiv_Load('F:\SMC2015\Ver2.emotiv\yjkee-123-19.02.16.19.36.31.edf'));
