echo on

mex -DranSHR3 sample_mvgm.c

echo off